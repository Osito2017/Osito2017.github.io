//Enable for 24 hour clock
var hours24 = false;

//Change weather units
var units = 'c';

//Change Location
var weatherLocation = 'London';

var woeidStatus = false;

var woeidLoc = '91653498';

// Hide elements

var hideTime = false;

var hideDate = false;

var hideBattery = false;

var hideWeather = false;

